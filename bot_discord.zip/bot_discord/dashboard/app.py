# dashboard/app.py
from flask import Flask, jsonify, request, render_template, abort
from config import DASHBOARD_SECRET_KEY
from database import get_session
from models import TaskConfig, MessageGroup, Message
import json
import datetime


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = DASHBOARD_SECRET_KEY

    # ── Página principal ──────────────────────────────────────────────────────

    @app.route("/")
    def index():
        return render_template("index.html")

    # ══════════════════════════════════════════════════════════════════════════
    # API — Grupos de Mensagens
    # ══════════════════════════════════════════════════════════════════════════

    @app.route("/api/groups", methods=["GET"])
    def list_groups():
        with get_session() as s:
            groups = s.query(MessageGroup).order_by(MessageGroup.id).all()
            return jsonify([_serialize_group(g) for g in groups])

    @app.route("/api/groups", methods=["POST"])
    def create_group():
        data = request.get_json(force=True)
        name = (data.get("name") or "").strip()
        if not name:
            abort(400, "name é obrigatório")
        with get_session() as s:
            g = MessageGroup(
                name=name,
                description=data.get("description", ""),
            )
            s.add(g)
            s.flush()
            result = _serialize_group(g)
        return jsonify(result), 201

    @app.route("/api/groups/<int:gid>", methods=["GET"])
    def get_group(gid):
        with get_session() as s:
            g = s.query(MessageGroup).get(gid)
            if not g:
                abort(404)
            return jsonify(_serialize_group(g, include_messages=True))

    @app.route("/api/groups/<int:gid>", methods=["PUT"])
    def update_group(gid):
        data = request.get_json(force=True)
        with get_session() as s:
            g = s.query(MessageGroup).get(gid)
            if not g:
                abort(404)
            if "name" in data and data["name"].strip():
                g.name = data["name"].strip()
            if "description" in data:
                g.description = data["description"]
            return jsonify(_serialize_group(g))

    @app.route("/api/groups/<int:gid>", methods=["DELETE"])
    def delete_group(gid):
        with get_session() as s:
            g = s.query(MessageGroup).get(gid)
            if not g:
                abort(404)
            s.delete(g)
        return jsonify({"ok": True})

    # ── Mensagens dentro de grupos ────────────────────────────────────────────

    @app.route("/api/groups/<int:gid>/messages", methods=["POST"])
    def add_message(gid):
        data = request.get_json(force=True)
        content = (data.get("content") or "").strip()
        if not content:
            abort(400, "content é obrigatório")
        with get_session() as s:
            g = s.query(MessageGroup).get(gid)
            if not g:
                abort(404, "Grupo não encontrado")
            m = Message(group_id=gid, content=content, active=True)
            s.add(m)
            s.flush()
            result = _serialize_message(m)
        return jsonify(result), 201

    @app.route("/api/messages/<int:mid>", methods=["PUT"])
    def update_message(mid):
        data = request.get_json(force=True)
        with get_session() as s:
            m = s.query(Message).get(mid)
            if not m:
                abort(404)
            if "content" in data:
                m.content = data["content"]
            if "active" in data:
                m.active = bool(data["active"])
            return jsonify(_serialize_message(m))

    @app.route("/api/messages/<int:mid>", methods=["DELETE"])
    def delete_message(mid):
        with get_session() as s:
            m = s.query(Message).get(mid)
            if not m:
                abort(404)
            s.delete(m)
        return jsonify({"ok": True})

    # ══════════════════════════════════════════════════════════════════════════
    # API — Tasks
    # ══════════════════════════════════════════════════════════════════════════

    @app.route("/api/tasks", methods=["GET"])
    def list_tasks():
        with get_session() as s:
            tasks = s.query(TaskConfig).order_by(TaskConfig.id).all()
            return jsonify([_serialize_task(t) for t in tasks])

    @app.route("/api/tasks", methods=["POST"])
    def create_task():
        data = request.get_json(force=True)
        errors = _validate_task(data)
        if errors:
            abort(400, "; ".join(errors))
        with get_session() as s:
            t = TaskConfig(
                name=data["name"].strip(),
                description=data.get("description", ""),
                type=data["type"],
                channel_ids=_normalize_channel_ids(data["channel_ids"]),
                message_group_id=data.get("message_group_id"),
                schedule_config=json.dumps(data.get("schedule_config", {})),
                active=data.get("active", True),
            )
            s.add(t)
            s.flush()
            result = _serialize_task(t)
        return jsonify(result), 201

    @app.route("/api/tasks/<int:tid>", methods=["GET"])
    def get_task(tid):
        with get_session() as s:
            t = s.query(TaskConfig).get(tid)
            if not t:
                abort(404)
            return jsonify(_serialize_task(t))

    @app.route("/api/tasks/<int:tid>", methods=["PUT"])
    def update_task(tid):
        data = request.get_json(force=True)
        with get_session() as s:
            t = s.query(TaskConfig).get(tid)
            if not t:
                abort(404)
            if "name" in data and data["name"].strip():
                t.name = data["name"].strip()
            if "description" in data:
                t.description = data["description"]
            if "type" in data:
                t.type = data["type"]
            if "channel_ids" in data:
                t.channel_ids = _normalize_channel_ids(data["channel_ids"])
            if "message_group_id" in data:
                t.message_group_id = data["message_group_id"]
            if "schedule_config" in data:
                t.schedule_config = json.dumps(data["schedule_config"])
            if "active" in data:
                t.active = bool(data["active"])
            t.updated_at = datetime.datetime.utcnow()
            return jsonify(_serialize_task(t))

    @app.route("/api/tasks/<int:tid>", methods=["DELETE"])
    def delete_task(tid):
        with get_session() as s:
            t = s.query(TaskConfig).get(tid)
            if not t:
                abort(404)
            s.delete(t)
        return jsonify({"ok": True})

    @app.route("/api/tasks/<int:tid>/toggle", methods=["POST"])
    def toggle_task(tid):
        with get_session() as s:
            t = s.query(TaskConfig).get(tid)
            if not t:
                abort(404)
            t.active = not t.active
            t.updated_at = datetime.datetime.utcnow()
            return jsonify({"id": t.id, "active": t.active})

    # ── Erros JSON ────────────────────────────────────────────────────────────

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(500)
    def handle_error(e):
        return jsonify({"error": str(e)}), e.code

    return app


# ── Serializers ───────────────────────────────────────────────────────────────

def _serialize_message(m: Message) -> dict:
    return {
        "id": m.id,
        "group_id": m.group_id,
        "content": m.content,
        "active": m.active,
        "created_at": m.created_at.isoformat() if m.created_at else None,
    }


def _serialize_group(g: MessageGroup, include_messages: bool = True) -> dict:
    d = {
        "id": g.id,
        "name": g.name,
        "description": g.description,
        "message_count": len(g.messages),
        "created_at": g.created_at.isoformat() if g.created_at else None,
    }
    if include_messages:
        d["messages"] = [_serialize_message(m) for m in g.messages]
    return d


def _serialize_task(t: TaskConfig) -> dict:
    return {
        "id": t.id,
        "name": t.name,
        "description": t.description,
        "type": t.type,
        "channel_ids": t.channel_ids,
        "message_group_id": t.message_group_id,
        "schedule_config": json.loads(t.schedule_config or "{}"),
        "active": t.active,
        "created_at": t.created_at.isoformat() if t.created_at else None,
        "updated_at": t.updated_at.isoformat() if t.updated_at else None,
    }


# ── Validação ─────────────────────────────────────────────────────────────────

VALID_TYPES = {"weekly", "biweekly", "monthly", "daily_time", "interval_days"}


def _validate_task(data: dict) -> list[str]:
    errors = []
    if not data.get("name", "").strip():
        errors.append("name é obrigatório")
    if data.get("type") not in VALID_TYPES:
        errors.append(f"type deve ser um de: {', '.join(VALID_TYPES)}")
    if not data.get("channel_ids"):
        errors.append("channel_ids é obrigatório")
    return errors


def _normalize_channel_ids(raw) -> str:
    """Aceita lista ou string separada por vírgula, retorna string limpa."""
    if isinstance(raw, list):
        return ",".join(str(x).strip() for x in raw if str(x).strip())
    return ",".join(x.strip() for x in str(raw).split(",") if x.strip())
