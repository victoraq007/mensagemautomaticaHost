# models.py
from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime

Base = declarative_base()


class Settings(Base):
    """Chave-valor geral para estado das tasks (ex: última semana enviada)."""
    __tablename__ = "settings"
    id    = Column(Integer, primary_key=True)
    key   = Column(String(100), unique=True, nullable=False)
    value = Column(String(500), nullable=False)

    def __repr__(self):
        return f"<Settings(key={self.key!r}, value={self.value!r})>"


class MessageGroup(Base):
    """
    Grupo de mensagens — ex: 'Avisos Semanais', 'Lembretes de Ponto'.
    Cada grupo tem uma lista de mensagens e pode ser associado a múltiplas tasks.
    """
    __tablename__ = "message_groups"
    id          = Column(Integer, primary_key=True)
    name        = Column(String(200), nullable=False)
    description = Column(Text, default="")
    created_at  = Column(DateTime, default=datetime.datetime.utcnow)

    messages = relationship("Message", back_populates="group", cascade="all, delete-orphan")
    tasks    = relationship("TaskConfig", back_populates="message_group")

    def __repr__(self):
        return f"<MessageGroup(name={self.name!r})>"


class Message(Base):
    """Mensagem individual dentro de um grupo."""
    __tablename__ = "messages"
    id         = Column(Integer, primary_key=True)
    group_id   = Column(Integer, ForeignKey("message_groups.id"), nullable=False)
    content    = Column(Text, nullable=False)
    active     = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    group = relationship("MessageGroup", back_populates="messages")

    def __repr__(self):
        return f"<Message(id={self.id}, group_id={self.group_id})>"


class TaskConfig(Base):
    """
    Configuração de uma task agendada.
    - type: 'weekly' | 'biweekly' | 'monthly' | 'daily_time' | 'interval_days'
    - channel_ids: IDs Discord separados por vírgula
    - schedule_config: JSON string com parâmetros específicos do tipo
      Ex weekly:         {"days_of_week": [0,1,2,3,4], "hour_start": 9, "hour_end": 18}
      Ex daily_time:     {"time": "09:00", "days": [16,17,18,19,20,21]}
      Ex interval_days:  {"days": 10, "hour_start": 15, "hour_end": 23}
    """
    __tablename__ = "task_configs"
    id              = Column(Integer, primary_key=True)
    name            = Column(String(200), nullable=False)
    description     = Column(Text, default="")
    type            = Column(String(50), nullable=False)
    channel_ids     = Column(Text, nullable=False)      # "123,456,789"
    message_group_id = Column(Integer, ForeignKey("message_groups.id"), nullable=True)
    schedule_config = Column(Text, default="{}")         # JSON
    active          = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    message_group = relationship("MessageGroup", back_populates="tasks")

    def get_channel_ids(self):
        """Retorna lista de ints com os IDs dos canais."""
        return [int(x.strip()) for x in self.channel_ids.split(",") if x.strip()]

    def __repr__(self):
        return f"<TaskConfig(name={self.name!r}, type={self.type!r}, active={self.active})>"
