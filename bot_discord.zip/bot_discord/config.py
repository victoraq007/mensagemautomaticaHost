# config.py
import os
import pytz
from dotenv import load_dotenv

load_dotenv()

# ── Modo ───────────────────────────────────────────────
DEBUG = os.getenv("DEBUG", "false").lower() == "true"
TIMEZONE = pytz.timezone("America/Sao_Paulo")

# ── Discord ────────────────────────────────────────────
TOKEN = os.getenv("DISCORD_TOKEN", "")
if not TOKEN:
    raise ValueError("DISCORD_TOKEN não definido no .env")

# ── Dashboard ──────────────────────────────────────────
DASHBOARD_SECRET_KEY = os.getenv("DASHBOARD_SECRET_KEY", "dev-secret-change-me")
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", 5000))
DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "0.0.0.0")

# ── Google Sheets (opcional) ───────────────────────────
GOOGLE_SHEETS_CREDENTIALS = os.getenv("GOOGLE_SHEETS_CREDENTIALS", "credentials/credentials.json")
GOOGLE_SHEETS_SPREADSHEET = os.getenv("GOOGLE_SHEETS_SPREADSHEET", "")
GOOGLE_SHEETS_WORKSHEET   = os.getenv("GOOGLE_SHEETS_WORKSHEET", "")
