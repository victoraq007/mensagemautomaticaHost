# cogs/tasks_cog.py
"""
TasksCog — todas as tarefas agendadas do bot.

Arquitetura:
  - Todas as configurações (canais, mensagens, recorrência) vêm do banco de dados.
  - Um único loop principal (dispatcher) roda a cada minuto e delega para handlers.
  - Tasks com agendamento aleatório de horário (interval_days) usam estado interno
    para registrar o horário escolhido no dia — sem asyncio.sleep longo dentro do loop.
  - Sessões de banco são abertas e fechadas por operação (get_session()).
"""

import json
import random
import datetime
import asyncio

from discord.ext import tasks, commands

from config import TIMEZONE
from database import get_session
from models import Settings, TaskConfig, MessageGroup
from logger_setup import make_logger, purge_old_logs


# ── Helpers ──────────────────────────────────────────────────────────────────

def now_tz() -> datetime.datetime:
    return datetime.datetime.now(TIMEZONE)


def _get_setting(key: str, default=None):
    with get_session() as s:
        row = s.query(Settings).filter_by(key=key).first()
        return row.value if row else default


def _set_setting(key: str, value: str):
    with get_session() as s:
        row = s.query(Settings).filter_by(key=key).first()
        if row:
            row.value = value
        else:
            s.add(Settings(key=key, value=value))


def _active_tasks():
    with get_session() as s:
        return s.query(TaskConfig).filter_by(active=True).all()


def _pick_message(task: TaskConfig) -> str | None:
    """Escolhe mensagem aleatória do grupo vinculado à task."""
    if not task.message_group_id:
        return None
    with get_session() as s:
        group = s.query(MessageGroup).get(task.message_group_id)
        if not group:
            return None
        active_msgs = [m.content for m in group.messages if m.active]
        return random.choice(active_msgs) if active_msgs else None


# ── Cog ──────────────────────────────────────────────────────────────────────

class TasksCog(commands.Cog):
    def __init__(self, bot: commands.Bot, geral_logger):
        self.bot          = bot
        self.logger       = geral_logger
        self.task_logger  = make_logger("discord_bot.tasks", "tasks.log")

        # Estado interno para tasks do tipo interval_days:
        # { task_id: "HH:MM" }  — horário escolhido para o dia atual
        self._scheduled_times: dict[int, str] = {}

        self.dispatcher.start()
        self.daily_maintenance.start()

    def cog_unload(self):
        self.dispatcher.cancel()
        self.daily_maintenance.cancel()

    # ── Eventos ──────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_ready(self):
        self.logger.info(f"TasksCog pronto | bot={self.bot.user}")
        print(f"[BOT] Conectado como {self.bot.user}")

    # ── Loop principal ────────────────────────────────────────────────────────

    @tasks.loop(minutes=1)
    async def dispatcher(self):
        """Roda a cada minuto e aciona os handlers corretos para cada task ativa."""
        now = now_tz()
        try:
            tasks_list = _active_tasks()
        except Exception as e:
            self.task_logger.exception(f"Erro ao carregar tasks do banco: {e}")
            return

        for task in tasks_list:
            try:
                cfg = json.loads(task.schedule_config or "{}")
                handler = self._get_handler(task.type)
                if handler:
                    await handler(task, cfg, now)
            except Exception as e:
                self.task_logger.exception(
                    f"Erro no dispatcher | task_id={task.id} name={task.name!r}: {e}"
                )

    @dispatcher.before_loop
    async def before_dispatcher(self):
        await self.bot.wait_until_ready()
        self.task_logger.info("Dispatcher iniciado.")

    # ── Manutenção diária ─────────────────────────────────────────────────────

    @tasks.loop(hours=24)
    async def daily_maintenance(self):
        """Purga logs antigos e reseta o estado de agendamento de horário."""
        removed = purge_old_logs()
        self._scheduled_times.clear()
        self.task_logger.info(
            f"Manutenção diária: {removed} arquivo(s) de log removido(s)."
        )

    @daily_maintenance.before_loop
    async def before_daily_maintenance(self):
        await self.bot.wait_until_ready()

    # ── Roteador de handlers ──────────────────────────────────────────────────

    def _get_handler(self, task_type: str):
        return {
            "weekly":        self._handle_weekly,
            "biweekly":      self._handle_biweekly,
            "monthly":       self._handle_monthly,
            "daily_time":    self._handle_daily_time,
            "interval_days": self._handle_interval_days,
        }.get(task_type)

    # ── Handlers por tipo ─────────────────────────────────────────────────────

    async def _handle_weekly(self, task: TaskConfig, cfg: dict, now: datetime.datetime):
        """
        Envia UMA vez por semana.
        cfg: {"hour_start": 9, "hour_end": 18, "days_of_week": [0,1,2,3,4]}
        """
        hour_start   = cfg.get("hour_start", 9)
        hour_end     = cfg.get("hour_end",   18)
        days_of_week = cfg.get("days_of_week", list(range(5)))  # seg–sex por padrão

        if now.weekday() not in days_of_week:
            return
        if not (hour_start <= now.hour < hour_end):
            return

        state_key   = f"task_{task.id}_last_week"
        current_week = now.isocalendar()[1]
        last_sent    = _get_setting(state_key)

        if str(current_week) == last_sent:
            return

        message = _pick_message(task)
        if not message:
            self.task_logger.warning(f"[weekly] task_id={task.id}: nenhuma mensagem ativa.")
            return

        await self._send_to_channels(task, message)
        _set_setting(state_key, str(current_week))
        self.task_logger.info(f"[weekly] task_id={task.id} | semana={current_week} | enviada.")

    async def _handle_biweekly(self, task: TaskConfig, cfg: dict, now: datetime.datetime):
        """
        Envia quinzenalmente (dias divisíveis por 15).
        cfg: {"hour": 9}
        """
        if now.day % 15 != 0:
            return
        if now.hour != cfg.get("hour", 9) or now.minute != 0:
            return

        state_key  = f"task_{task.id}_last_biweek"
        date_str   = now.strftime("%Y-%m-%d")
        last_sent  = _get_setting(state_key)

        if date_str == last_sent:
            return

        message = _pick_message(task)
        if not message:
            return

        await self._send_to_channels(task, message)
        _set_setting(state_key, date_str)
        self.task_logger.info(f"[biweekly] task_id={task.id} | data={date_str} | enviada.")

    async def _handle_monthly(self, task: TaskConfig, cfg: dict, now: datetime.datetime):
        """
        Envia UMA vez por mês.
        cfg: {"hour_start": 9, "hour_end": 18}
        """
        hour_start = cfg.get("hour_start", 9)
        hour_end   = cfg.get("hour_end",   18)

        if not (hour_start <= now.hour < hour_end):
            return

        state_key   = f"task_{task.id}_last_month"
        current_month = now.month
        last_sent     = _get_setting(state_key)

        if str(current_month) == last_sent:
            return

        message = _pick_message(task)
        if not message:
            return

        await self._send_to_channels(task, message)
        _set_setting(state_key, str(current_month))
        self.task_logger.info(f"[monthly] task_id={task.id} | mês={current_month} | enviada.")

    async def _handle_daily_time(self, task: TaskConfig, cfg: dict, now: datetime.datetime):
        """
        Envia em horários fixos em dias específicos do mês.
        cfg: {"times": ["09:00", "18:00"], "days": [16,17,18,19,20,21]}
        """
        allowed_days  = cfg.get("days",  [])
        allowed_times = cfg.get("times", [])

        if now.day not in allowed_days:
            return

        current_time = now.strftime("%H:%M")
        if current_time not in allowed_times:
            return

        # Debounce: garante envio único por (task, dia, horário)
        state_key = f"task_{task.id}_sent_{now.strftime('%Y%m%d')}_{current_time.replace(':','')}"
        if _get_setting(state_key):
            return

        message = _pick_message(task)
        if not message:
            return

        await self._send_to_channels(task, message)
        _set_setting(state_key, "1")
        self.task_logger.info(
            f"[daily_time] task_id={task.id} | {now.strftime('%Y-%m-%d %H:%M')} | enviada."
        )

    async def _handle_interval_days(self, task: TaskConfig, cfg: dict, now: datetime.datetime):
        """
        Envia a cada N dias, em horário aleatório dentro de uma janela.
        cfg: {"days": 10, "hour_start": 15, "hour_end": 23}
        O horário é escolhido uma vez por dia e persistido no estado.
        """
        required_days = cfg.get("days", 10)
        hour_start    = cfg.get("hour_start", 15)
        hour_end      = cfg.get("hour_end",   23)

        today = now.date()
        today_str = today.strftime("%Y-%m-%d")

        state_key_last = f"task_{task.id}_last_interval"
        last_sent_str  = _get_setting(state_key_last)

        if last_sent_str:
            last_sent_date = datetime.datetime.strptime(last_sent_str, "%Y-%m-%d").date()
            days_since     = (today - last_sent_date).days
        else:
            days_since = required_days  # força envio na primeira execução

        if days_since < required_days:
            return

        # Escolhe (ou recupera) o horário aleatório para hoje
        sched_key = f"task_{task.id}_sched_{today_str}"
        sched_time = self._scheduled_times.get(task.id) or _get_setting(sched_key)

        if not sched_time:
            hour   = random.randint(hour_start, hour_end - 1)
            minute = random.randint(0, 59)
            sched_time = f"{hour:02d}:{minute:02d}"
            self._scheduled_times[task.id] = sched_time
            _set_setting(sched_key, sched_time)
            self.task_logger.info(
                f"[interval_days] task_id={task.id} | horário agendado={sched_time}"
            )

        if now.strftime("%H:%M") != sched_time:
            return

        message = _pick_message(task)
        if not message:
            return

        await self._send_to_channels(task, message)
        _set_setting(state_key_last, today_str)
        self._scheduled_times.pop(task.id, None)
        self.task_logger.info(
            f"[interval_days] task_id={task.id} | {today_str} {sched_time} | enviada."
        )

    # ── Envio para canais ─────────────────────────────────────────────────────

    async def _send_to_channels(self, task: TaskConfig, message: str):
        """Envia a mensagem para todos os canais configurados na task."""
        channel_ids = task.get_channel_ids()
        if not channel_ids:
            self.task_logger.warning(f"task_id={task.id}: nenhum canal configurado.")
            return

        for channel_id in channel_ids:
            channel = self.bot.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(message)
                    self.task_logger.info(
                        f"task_id={task.id} | canal={channel_id} | mensagem enviada."
                    )
                except Exception as e:
                    self.task_logger.exception(
                        f"task_id={task.id} | canal={channel_id} | erro ao enviar: {e}"
                    )
            else:
                self.task_logger.error(
                    f"task_id={task.id} | canal={channel_id} não encontrado no Discord."
                )

    # ── Comandos utilitários ──────────────────────────────────────────────────

    @commands.command(name="listar_canais")
    async def listar_canais(self, ctx):
        """Lista todos os canais acessíveis pelo bot."""
        linhas = ["**Canais acessíveis:**"]
        for guild in self.bot.guilds:
            for channel in guild.channels:
                linhas.append(f"`{channel.id}` — {guild.name} / #{channel.name}")
        # Discord limita mensagens a 2000 chars
        msg = "\n".join(linhas)
        if len(msg) > 1900:
            msg = msg[:1900] + "\n... (lista truncada)"
        await ctx.send(msg)

    @commands.command(name="status_tasks")
    async def status_tasks(self, ctx):
        """Mostra o status das tasks ativas."""
        tasks_list = _active_tasks()
        if not tasks_list:
            await ctx.send("Nenhuma task ativa.")
            return
        linhas = ["**Tasks ativas:**"]
        for t in tasks_list:
            linhas.append(f"• `{t.id}` **{t.name}** — tipo: `{t.type}` | canais: `{t.channel_ids}`")
        await ctx.send("\n".join(linhas))
